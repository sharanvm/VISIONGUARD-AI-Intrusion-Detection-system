from flask import Flask, render_template, request, jsonify
import cv2
import face_recognition
import numpy as np
import pymongo
import os
import time
import smtplib
from email.message import EmailMessage
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from bson.binary import Binary

app = Flask(__name__)

# MongoDB Connection
MONGO_URI = "mongodb+srv://bhoomika1373:poqFZ4t40S3s5zNv@cluster0.t1heo.mongodb.net/"
client = pymongo.MongoClient(MONGO_URI)
db = client["security_system"]
owner_collection = db["owner_pics"]
intruder_collection = db["intruder_pics"]

# Email Configuration
EMAIL_ADDRESS = "bhoomika1373@gmail.com"
EMAIL_PASSWORD = "ppoayjrrrlpwknjd"
RECIPIENT_EMAIL = "bhoomika3713@gmail.com"

# Motion Detection Settings
LOCKER_AREA = (100, 100, 500, 500)  # (x1, y1, x2, y2)
MOTION_THRESHOLD = 5000
ALERT_COOLDOWN = 60  # seconds
last_alert_time = 0

# Load Owner Images from MongoDB
def load_owner_encodings():
    encodings = []
    for owner in owner_collection.find():
        owner_image = np.frombuffer(owner['image'], dtype=np.uint8)
        image = cv2.imdecode(owner_image, cv2.IMREAD_COLOR)
        face_encoding = face_recognition.face_encodings(image)
        if face_encoding:
            encodings.append(face_encoding[0])
    return encodings

def add_owner_images():
    """Allow the user to add 1 to 10 owner images (capture or upload)."""
    num_images = 0
    while num_images < 1 or num_images > 10:
        try:
            num_images = int(input("Enter number of owner images to add (1-10): "))
            if num_images < 1 or num_images > 10:
                print("⚠️ Please enter a number between 1 and 10.")
        except ValueError:
            print("⚠️ Invalid input. Please enter a number between 1 and 10.")

    for i in range(num_images):
        choice = input(f"Image {i+1}: Press 'C' to capture or 'U' to upload an image (Q to quit): ").lower()
        if choice == 'c':
            cap = cv2.VideoCapture(0)
            ret, frame = cap.read()
            cap.release()
        elif choice == 'u':
            path = input("Enter the image path: ")
            frame = cv2.imread(path)
        elif choice == 'q':
            break
        else:
            print("Invalid choice. Try again.")
            continue

        if frame is not None:
            _, encoded_image = cv2.imencode('.jpg', frame)
            image_binary = Binary(encoded_image.tobytes())
            owner_collection.insert_one({"image": image_binary})
            print(f"✅ Owner image {i+1} added successfully.")

    global owner_encodings
    owner_encodings = load_owner_encodings()

# Initialize Owner Encodings
owner_encodings = load_owner_encodings()

# Motion Detector
fgbg = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=16, detectShadows=False)

def send_email_with_images(image_data_list):
    """Send an email with multiple intruder images attached."""
    msg = MIMEMultipart()
    msg['Subject'] = "🚨 Security Alert: Intruder Detected!"
    msg['From'] = EMAIL_ADDRESS
    msg['To'] = RECIPIENT_EMAIL
    
    for idx, image_data in enumerate(image_data_list):
        img = MIMEImage(image_data)
        img.add_header('Content-Disposition', 'attachment', filename=f"intruder_{idx + 1}.jpg")
        msg.attach(img)
    
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.send_message(msg)
        print("📩 Email sent successfully with 10 intruder images!")
    except Exception as e:
        print(f"❌ Email sending failed: {e}")

def store_intruder_image(image):
    """Store intruder image in MongoDB."""
    _, encoded_image = cv2.imencode('.jpg', image)
    image_binary = Binary(encoded_image.tobytes())
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    intruder_collection.insert_one({"timestamp": timestamp, "image": image_binary})
    print("📸 Intruder image stored in MongoDB.")

def detect_motion(frame):
    """Detect motion in the specified area."""
    fgmask = fgbg.apply(frame)
    _, thresh = cv2.threshold(fgmask, 127, 255, cv2.THRESH_BINARY)
    x1, y1, x2, y2 = LOCKER_AREA
    roi = thresh[y1:y2, x1:x2]
    contours, _ = cv2.findContours(roi, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return any(cv2.contourArea(contour) > MOTION_THRESHOLD for contour in contours)

def detect_intruder(frame):
    """Check if an intruder is present in the frame."""
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    face_locations = face_recognition.face_locations(rgb_frame)
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

    if len(face_encodings) == 0:
        return True  # No faces detected, consider it suspicious

    for encoding in face_encodings:
        matches = face_recognition.compare_faces(owner_encodings, encoding, tolerance=0.5)
        if any(matches):
            return False  # Recognized owner
    return True

def main_security_loop():
    """Main loop to detect intruders and send an alert with 10 captured images."""
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    global last_alert_time

    print("🎥 Security system activated. Press 'Q' to exit.")
    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        motion_detected = detect_motion(frame)
        intruder_detected = detect_intruder(frame)
        alert_triggered = False

        if motion_detected and intruder_detected:
            if time.time() - last_alert_time > ALERT_COOLDOWN:
                print("🚨 Intruder detected! Capturing 10 images and sending an alert.")

                intruder_images = []
                for i in range(10):
                    ret, frame = cap.read()
                    if ret:
                        store_intruder_image(frame)
                        _, encoded_image = cv2.imencode('.jpg', frame)
                        intruder_images.append(encoded_image.tobytes())
                        print(f"📸 Captured intruder image {i + 1}/10")
                    time.sleep(1)  # Short delay to get varied images

                send_email_with_images(intruder_images)
                last_alert_time = time.time()
                alert_triggered = True

        status_text = f"Motion: {motion_detected} | Intruder: {intruder_detected} | Alert: {alert_triggered}"
        cv2.putText(frame, status_text, (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        x1, y1, x2, y2 = LOCKER_AREA
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.imshow('Security System', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    print("🔒 Security system shutdown.")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/detect')
def detect():
    return render_template('detect.html')

@app.route('/upload_owner_image', methods=['POST'])
def upload_owner_image():
    print("📥 Received image upload request")

    if owner_collection.count_documents({}) >= 10:
        return jsonify({"error": "Maximum of 10 owner images already uploaded."})

    if 'file' not in request.files:
        return jsonify({"error": "No file part in the request."})

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected."})

    # Read and decode image
    in_memory_file = file.read()
    np_img = np.frombuffer(in_memory_file, dtype=np.uint8)
    img = cv2.imdecode(np_img, cv2.IMREAD_COLOR)

    if img is None:
        return jsonify({"error": "Failed to decode image."})

    # Detect face
    face_encoding = face_recognition.face_encodings(img)
    if not face_encoding:
        return jsonify({"error": "No face detected in the image."})

    # Encode and store in MongoDB
    _, encoded_image = cv2.imencode('.jpg', img)
    image_binary = Binary(encoded_image.tobytes())
    result = owner_collection.insert_one({"image": image_binary})
    print("📝 Stored image in MongoDB with ID:", result.inserted_id)

    return jsonify({"message": "Owner image added successfully."})


if __name__ == "__main__":
    app.run(debug=True)
